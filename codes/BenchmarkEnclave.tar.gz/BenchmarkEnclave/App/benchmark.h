#ifndef BENCHMARK_H    // To make sure you don't declare the function more than once by including the header multiple times.
#define BENCHMARK_H

#define MAX_ELEMENT 1000000

void test_sequential_read(void);
void test_sequential_write(void);
void test_random_read(void);
void test_random_write(void);

#endif
