#include <stdlib.h>
#include "benchmark.h"

void test_sequential_read(){
  int k, tmp = 0;
  int array[MAX_ELEMENT];
  for (int i = 0; i < MAX_ELEMENT; i++ ){
    int k = rand();
    tmp = array[i];
  }
}

void test_sequential_write(){
  int k, tmp = 0;
  int array[MAX_ELEMENT];
  for (int i = 0; i < MAX_ELEMENT; i++ ){
    int k = rand();
    array[i]=k;
  }
}

void test_random_write(){
  int k, tmp = 0;
  int array[MAX_ELEMENT];
  for (int i = 0; i < MAX_ELEMENT; i++ ){
    k = rand();
    int idx = k % MAX_ELEMENT;
    array[idx]=k;
  }
}

void test_random_read(){
  int k, tmp = 0;
  int array[MAX_ELEMENT];
  for (int i = 0; i < MAX_ELEMENT; i++ ){
    k = rand();
    int idx = k % MAX_ELEMENT;
    tmp = array[idx];
  }
}
